#ifndef INS_H
#define INS_H
#include <string>


class Ins {
public:

	std::string ime;
	std::string opcode;


};
#endif