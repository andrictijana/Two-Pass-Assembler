#ifndef TABELASIMBOLA_H
#define TABELASIMBOLA_H
#include <map>
#include <iostream>
#include <string>

using namespace std; 

//locGlob = local; lokalni

//locGlob = global; globalni

class Simbol {
 
	string ime;
	string sekcija;
	int vrednost;
	string locGlob;
    int rb;

public:

	Simbol(string ime, string sekcija,int vrednost,string locGlob,int rb) : ime(ime),sekcija(sekcija),vrednost(vrednost),locGlob(locGlob),rb(rb) {

	}

	string getIme() {
		return ime;
	}

	string getSekcija() {
		return sekcija;
	}
	
	int getVrednost() {
		return vrednost;
	}
	string getLG() {
		return locGlob;
	}

	int getRb() {

		return rb;
	}

	void setVrednost(int v) {
		vrednost=v;
	}

	void setLG(string s) {
             locGlob=s;
	}

};
class TabelaSimbola {
public:

	map<std::string,Simbol *> mapa;

	TabelaSimbola();
	~TabelaSimbola();


	Simbol * get(string i);

	void put(Simbol *, string);
	


};
#endif
