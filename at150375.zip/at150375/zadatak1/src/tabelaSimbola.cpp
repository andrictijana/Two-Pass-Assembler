
#include "TabelaSimbola.h"

using namespace std;


TabelaSimbola::TabelaSimbola() {

}

TabelaSimbola::~TabelaSimbola() {

}


Simbol * TabelaSimbola::get(string s ) {
	Simbol * ret=mapa[s];

	if (ret == 0) {
	 return 0;
	}

	return ret;
	

}


void TabelaSimbola::put(Simbol * value, string key) {

	Simbol * s=mapa[key];
	if (s != 0){  cout << "vec postoji simbol"; return; }
	mapa[key]=value;
}