
#include  "Asembler.h"


#include <regex>
#include <math.h>
#include <bitset>
TabelaSimbola *  Asembler::tabelaSimbola;
vector<Sekcija> Asembler::duzineSekcija;
map<string, RelZapisi *> Asembler::mapaRel;
map<string,GenerisanKod *>Asembler::mapaGenKoda;

Asembler::Asembler(int rb,int pocAdresa):rb(rb),pocAdresa(pocAdresa) {

	if (rb < 5) {
		cout << " Morate uneti redni broj veci od 5, od koga ce poceti redjanje elemenata u tabelu simbola ";

		return;
	}
	
	tabelaSimbola=new TabelaSimbola();

	Simbol * simbol=new Simbol("UND","UND",0,"local",0);

     tabelaSimbola->put(simbol,"UND");


	 helper=new Helper();


	 trenutnaSekcija="";

	 //popunjavam deo za kod
	 GenerisanKod * novi=new GenerisanKod();
	 mapaGenKoda[".text"]=novi;

	 novi=new GenerisanKod();
	 mapaGenKoda[".data"]=novi;
	 novi=new GenerisanKod();
	 mapaGenKoda[".rodata"]=novi;


	 RelZapisi * noviZap=new RelZapisi();
	 mapaRel[".text"]=noviZap;
	 
	 noviZap=new RelZapisi();
	 mapaRel[".data"]=noviZap;

	 noviZap=new RelZapisi();
	 mapaRel[".rodata"]=noviZap;





}


Asembler::~Asembler() {
	delete tabelaSimbola;
	delete helper;

}

int Asembler::prviProlaz(ifstream & ulaz) {
	locationCnt=pocAdresa;
	string linija=helper->getLine(ulaz);
        regex rEND(".end");
	while (linija != ".end" ) {
                if (regex_search(linija,rEND)) {
break;
}
	                      regex rLinux("\\r");
smatch pomx;
regex_search(linija,pomx,rLinux);
linija=pomx.prefix().str();
	//da li ima nesto u liniji
		regex alfanum("[0-9|a-z|A-Z]+");
		if (!regex_search(linija,alfanum)) {
			linija=helper->getLine(ulaz);
			continue;
		}

		regex dvot("\\:");
		if (regex_search(linija,dvot)) {
			//znacii labela je sigurno
		 string ime;
		 smatch sm;

		 regex_search(linija,sm,alfanum);
		 ime=sm[0];
		 linija=sm.suffix().str();

		 Simbol * simb=tabelaSimbola->get(ime);
		 if (simb != 0){
			 if (simb->getLG() == "local" ) {
				 cout<< "ne mogu dva simbola sa istim imenom ";
			 } else {

				simb->setVrednost(locationCnt);
				
			 }
		 } else {
			 Simbol * novi=new Simbol(ime,trenutnaSekcija,locationCnt,"local",rb);
			 rb=rb + 1;
			 tabelaSimbola->put(novi,ime);

		 }

		 //uzmi dvotacku
		 regex_search(linija,sm,dvot);
		 linija=sm.suffix().str();




		}
		smatch sm1;
	    string sledecaRec;
		regex r("[0-9|a-z|A-Z|\.]+"); 
		
		if (!regex_search(linija,sm1,r)) {
			linija=helper->getLine(ulaz);
			continue;
		}

		sledecaRec=sm1[0];
		linija=sm1.suffix().str();

	    
		Ins * ins=helper->instrukcije[sledecaRec];
		if (ins != 0) {
			//neka ins je
			//da li je ins od dva ili cetiri bajta
			regex rret("ret");
			regex riret("iret");
			if (regex_search(ins->ime,rret) || regex_search(ins->ime,riret)) {
				locationCnt+=2;
				linija=helper->getLine(ulaz);
				continue;
			}
			regex znak("[\\[|\\]|\\$|\\*|\\&]");
            int flag4=0;
			int flag2=0;
			if (regex_search(linija,znak)) {
				flag4=flag4 + 1;
			} else {
				smatch reg1sm;
				regex registar("r[0-7]");
				if (regex_search(linija, reg1sm,registar)) {
					regex dva("[a-z|A-Z]{2}"); //prva dva slova instrukcije
					smatch dvaSmatch;
					regex_search(ins->ime,dvaSmatch,dva);
					string tmpIme=dvaSmatch.suffix().str();
					if (tmpIme == "push" || tmpIme == "pop" || tmpIme== "call" || tmpIme == "jmp" ) {
						flag2++;
					} else {
					linija=reg1sm.suffix().str();
					if (regex_search(linija,registar) ) {
						flag2++;
					} else {
						flag4++;
					}
					}
				} else {
					flag4=flag4 + 1;
				}
			}
			int oldLoc=locationCnt;
			if (flag2 == 1){
				locationCnt+=2;
			}
			if (flag4 == 1) {
				locationCnt+=4;
			}
			if (oldLoc == locationCnt) {
				cout << "greska, nema nikakvih adresiranja ";
			}
		    
			linija=helper->getLine(ulaz);
			continue;
		}

		//nije bila instrukcija

		if (sledecaRec == ".bss" || sledecaRec == ".text" || sledecaRec == ".data" || sledecaRec == ".rodata" ) {
			//znaci sekcija 
			  regex r("[^\.]+");
			  string sekcija;
			  smatch smsek;
			  regex_search(sledecaRec,smsek,r);
			  sekcija=smsek[0];
			  int rb=helper->redniBrojSekcije(sledecaRec);

			  
			  Simbol * novi=new Simbol(sledecaRec,sekcija, 0 , "local", rb);
			  tabelaSimbola->put(novi,sledecaRec);
			  if (trenutnaSekcija.length()> 1) {
				  //da stavim za prethodnu sekciju koja se zavrsila
				  Sekcija s(trenutnaSekcija,pocetakTrenSekcije,locationCnt);
				  duzineSekcija.push_back(s);
			  }
			  trenutnaSekcija=sledecaRec;
              linija=helper->getLine(ulaz);
			//  locationCnt=0;
			  pocetakTrenSekcije=locationCnt;
			  continue;
		}

		if (sledecaRec ==  ".char" || sledecaRec == ".word" || sledecaRec == ".long" ) {

			int dodatak=helper->uzmiVelicinuBajtaDirektive(sledecaRec);
			regex nijeZarez("[^\,]+");
			string tmp;
			smatch rez;

			while (regex_search(linija,rez,nijeZarez)) {
				locationCnt+=dodatak;

				linija=rez.suffix().str();
			}

			linija=helper->getLine(ulaz);
			continue;
		}

		if (sledecaRec == ".skip") {
			 
			regex broj("[0-9]+");
			smatch sm;
			regex_search(linija,sm, broj);

			string brojS=sm[0];
			
			locationCnt+=stoi(brojS);

			linija=helper->getLine(ulaz);
			continue;
		}


		if (sledecaRec == ".global") {

			regex nijeZarez("[^\,]+");
			smatch rez;
			while (regex_search(linija,rez,nijeZarez)) {
				smatch tijana;
				string xxx=rez[0];
				regex_search(xxx,tijana,alfanum);

				string ime=tijana[0];
				Simbol * simbol=tabelaSimbola->get(ime);
				if (simbol == 0) {
					Simbol * novi=new Simbol(ime,"UND", 0, "global", rb);
					rb=rb + 1;

					tabelaSimbola->put(novi,ime);

				} else {
					 
					if (simbol->getLG() == "local" ) simbol->setLG("global");
					else {
						cout << "greskalo linija 205";
					}

				}

				linija=rez.suffix().str();
			}


			linija=helper->getLine(ulaz);
			continue;
		}


		if ( sledecaRec == ".align" ) {
			//align= locationCnt da bude deljiv sa tim brojem na kvadrat???????
			smatch sm;
			regex digit("[0-9]+");
			if (regex_search(linija,sm,digit) ){

				int delilac=stoi(sm[0]);
				delilac=pow(2,delilac);
				int ostatak=locationCnt % delilac;
				if (ostatak == 0) {
					linija=helper->getLine(ulaz);
					continue;
				}
				locationCnt=locationCnt +  (delilac - ostatak);
				linija=helper->getLine(ulaz);
				continue;

			}else 
			{
				cout << "greska nema nista uz align, oko linije  247" << endl;
			}


		}

	

		


	}

	//treba ovde da dodam duzine sekcija svuda u prvom prolazu!
		 Sekcija s(trenutnaSekcija,pocetakTrenSekcije,locationCnt);
	     duzineSekcija.push_back(s);


	return 0;
}


int Asembler::drugiProlaz(ifstream & ulaz) {
	locationCnt=pocAdresa;
	string linija=helper->getLine(ulaz);
regex rEND(".end");
	
	while (linija != ".end" ) {

                if (regex_search(linija,rEND)) {
break;
}
                      regex rLinux("\\r");
smatch pomx;
regex_search(linija,pomx,rLinux);
linija=pomx.prefix().str();

		regex alfanum("[0-9|a-z|A-Z]+");
		regex alfa("[a-z|A-Z]+");
		regex digit("[0-9]+");
		if (!regex_search(linija,alfanum)) {
			linija=helper->getLine(ulaz);
			continue;
		}

		regex dvot("\\:");
		if (regex_search(linija,dvot)) {
			//znacii labela je sigurno
		 string ime;
		 smatch sm;
		 regex r("[a-z|A-Z|0-9]+\\:");
		 regex_search(linija,sm,r);
		 linija=sm.suffix().str();

		 if (!regex_search(linija,alfanum)) {
			linija=helper->getLine(ulaz);
			continue;
		}

		}
		smatch rez;
		string sledecaRec;
		regex r1("\.?[a-z|A-Z|0-9]+");
		
		regex_search(linija,rez,r1);
		sledecaRec=rez[0];
		linija=rez.suffix().str();

		Ins * ins=helper->instrukcije[sledecaRec];

		if (ins != 0) {
			//znaci neka instrukcija je;
			if (trenutnaSekcija != ".text" ) cout <<"greska oko linije 290, trenutna sekcija mora bititext";
			string opcod=ins->opcode;
			string prvaDvaBajta;
			//odredi nacin adresiranja za prvi operand

			regex iret("iret");
			if (regex_search(sledecaRec,iret)) {
				//znaci ret instrukcija je
				prvaDvaBajta=opcod + "0000000000";
				GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				string hexa=BinaryToHexa(prvaDvaBajta);
				gk->niz.push_back(hexa);

				linija=helper->getLine(ulaz);
				continue;
			}

			regex ret("ret");
			if (regex_search(sledecaRec,ret)) {
				//znaci ret je
				prvaDvaBajta=ins->opcode + "0111100000";
				GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				string hexa=BinaryToHexa(prvaDvaBajta);
				gk->niz.push_back(hexa);

				linija=helper->getLine(ulaz);
				continue;
			}

			regex jmp("jmp");
			int flagJmp=0;
			if( (regex_search(sledecaRec,jmp))) {
				//znaci jmp je
				flagJmp++;

			}

		    regex push("push");
			regex pop("pop");
			regex call("call");
		     

			if (regex_search(sledecaRec,push) || regex_search(sledecaRec,pop) || regex_search(sledecaRec,call) || flagJmp ) {
				//znaci odredim sada adresiranje prvog operanda!
				
				///////////// odredjivanje adresiranja ---------------------------------------------------------
				
				smatch sm1;
				regex registar("r[0-7]");
				int adresiranje=-1;
				string  promenljiva; //mora dabude promenljiva
				string pomeraj; //moze i broj i promenljiva
				string cistBroj; //mora da budebroj;
				if (regex_search(linija,sm1,registar)) {
					//znaci regdir je ili je regindpom
					//string registar=sm1[0];

				string regRez=sm1[0];
					smatch x;
					regex_search(regRez,x,digit);
					string rez123=x[0];
					int regBroj=stoi(rez123);
					string regBiti=DecimalToBinary(regBroj);
					
					
					linija=sm1.suffix().str();
					smatch sm2;
					regex spec("\\[.+\\]");
					if (regex_search(linija,sm2,spec)) {
						//znaci regindpom je
						string rez=sm2[0];
						prvaDvaBajta=opcod + "11" + regBiti + "00000";
						if (flagJmp) {
							prvaDvaBajta=opcod+ "01" + "111" + "11" + regBiti;
						}
						GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				        string hexa=BinaryToHexa(prvaDvaBajta);
				        gk->niz.push_back(hexa);
						adresiranje=3;
				        smatch pom;
						regex_search(rez,pom,alfanum);
						pomeraj=pom[0]; 

						Simbol * simb=tabelaSimbola->get(pomeraj);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							int brojalo=stoi(pomeraj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}
						
					} else {
						//znaci regdir je
						prvaDvaBajta=opcod + "01" + regBiti + "00000";
						if (flagJmp) {
							prvaDvaBajta=opcod + "01" + "111" + "01" + regBiti;
						}
						GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				        string hexa=BinaryToHexa(prvaDvaBajta);
			          	gk->niz.push_back(hexa);

						adresiranje=1;
						locationCnt+=2;
				        linija=helper->getLine(ulaz);
				        continue;
					}
				}
				else {
				regex dolar("\\$");
				smatch sm;
				if (regex_search(linija,sm,dolar)) {
					//znaci regindpom sa pc rel je
				    linija=sm.suffix().str();
					string registar="111";
					prvaDvaBajta=opcod+ "11" + registar + "00000";
					if (flagJmp) {
						prvaDvaBajta=opcod+ "01" + "111" + "11" + registar;
						regex bitovi("[0-1][0-1]");
						smatch bitoviS;
						regex_search(opcod,bitoviS,bitovi);
						string uslovniBitoviJMP=bitoviS[0];
						prvaDvaBajta=uslovniBitoviJMP + "0000" + "01" + "111" + "00" + "000"; //jmp prevodim kao add
					}
					GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				    string hexa=BinaryToHexa(prvaDvaBajta);
			     	gk->niz.push_back(hexa);

				    adresiranje=31; //kao 3 je za regindpom, a ovo jedinaca kaze da je dolar
					smatch pom;
					regex_search(linija,pom,alfanum);
					pomeraj=pom[0];

					Simbol * simb=tabelaSimbola->get(pomeraj);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							int brojalo=stoi(pomeraj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
				            if (flagJmp) {
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,true);
							int zaUgradjivanje; //= labela - sledeca lokacija
							if(simb->getLG()=="global" ){
							
								zaUgradjivanje=-2; 

							} else {
								zaUgradjivanje=simb->getVrednost() - locationCnt -4;
							}

							
							helper->ugradi(zaUgradjivanje,2,trenutnaSekcija);
							}else {
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
							}
						}


				} else {

					regex andR("\\&");
					
					if (regex_search(linija,andR)) {
						//immed je ali sa ovom &&
						smatch tmp;
						regex_search(linija,tmp,alfanum);
						promenljiva=tmp[0];
						adresiranje=4; // znaci ****************************************** 4 je za immed sa adresom
						prvaDvaBajta=opcod + "00" + "0000" + "0000";
						if (flagJmp) {
							prvaDvaBajta=opcod + "01" + "111" + "00" + "000";
						}
						GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				        string hexa=BinaryToHexa(prvaDvaBajta);
			     	    gk->niz.push_back(hexa);

						Simbol * simb=tabelaSimbola->get(promenljiva);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							cout << "greska oko linije 433, sa & mora da ide neki simbol,ne moze promenljiva";
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}

					} else {
						regex cifra("\ *[0-9]+\ *");
						if (regex_match(linija,cifra)) {
							//immed obicno je
							regex broj("[0-9]+");
							smatch tmpalo;
							regex_search(linija,tmpalo,broj);
							cistBroj=tmpalo[0];
							prvaDvaBajta=opcod + "00" + "0000" + "0000";
							if (flagJmp) {
								prvaDvaBajta=opcod  + "01" + "111" + "00" + "000";
							}
						    GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				            string hexa=BinaryToHexa(prvaDvaBajta);
			     	        gk->niz.push_back(hexa);
							adresiranje=0;

							int brojalo=stoi(cistBroj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
							
						} else {
							//znaci mora biti memdir
							smatch smat;
							regex zvezdica("\\*");
							if (regex_search(linija,smat,zvezdica)) {
								//znaci memidr sa zvezdicom je
								linija=smat.suffix().str();
								regex broj("[0-9]+");
								regex_search(linija,smat,broj);
								cistBroj=smat[0];

								prvaDvaBajta=opcod + "10" + "0000" + "0000";
								if (flagJmp) {
									prvaDvaBajta=opcod + "01" + "111" + "10" + "000";
								}
						        GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				                string hexa=BinaryToHexa(prvaDvaBajta);
			     	            gk->niz.push_back(hexa);
								adresiranje=21;

								int brojalo=stoi(cistBroj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
							

							} else {
								//znaci obican memdir je 
						        prvaDvaBajta=opcod + "10" + "0000" + "0000";
								if (flagJmp) {
									prvaDvaBajta=opcod + "01" + "111" + "10" + "000";
								}
						        GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				                string hexa=BinaryToHexa(prvaDvaBajta);
								 gk->niz.push_back(hexa);

								smatch tmp;
								regex_search(linija,tmp,alfanum);
								promenljiva=tmp[0];
								adresiranje=2;

								Simbol * simb=tabelaSimbola->get(promenljiva);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							cout << "greska oko linije 433, sa & mora da ide neki simbol,ne moze promenljiva";
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}
							}


						}
					}

				}

				}
				///----------------------------------------------------------------------------------------------

				//znaci radim sa pop push call i adresiranje sigurno nije regdir




             locationCnt+=4;
			 linija=helper->getLine(ulaz);
			 continue;
			} //kraj svega za push pop call 

			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			//znaci sgiruno je neka ins koja ima dva operanda !!
		    string duplikatLinija=linija;
		    //prekopiraj ovde ono za adresiranja sva da bih nasla kako izgleda operand2 samo, onda ces tek moci da kopiras ono odozgo sve
			regex zarez("[^\,]+");
			smatch rez;
			regex_search(duplikatLinija,rez,zarez);
			duplikatLinija=rez.suffix().str();
			string reg2;
			regex regIndPom("\\[");
			bool flagRegIndZagrada=false;
			bool DaLiJeOperandDvaRegDir=false;
			if(regex_search(duplikatLinija,regIndPom)) {
				flagRegIndZagrada=true;
				DaLiJeOperandDvaRegDir=false;
			smatch result;
					regex_search(duplikatLinija,result,digit);
					int dec=stoi(result[0]); //???????????????????????????????????????????
					reg2=DecimalToBinary(dec);

			} else {
				regex reg("r[0-7]");
				smatch rez1;
				if(regex_search(duplikatLinija,rez1,reg)) {
					DaLiJeOperandDvaRegDir=true;
					string tmp=rez1[0];
					regex_search(tmp,rez1,digit);
					int dec=stoi(rez1[0]); //???????????????????????????????????????????
					reg2=DecimalToBinary(dec);
					
				}
			}
			    smatch xyz;
				regex xyzr("[^\,]+");
			    string ostatakLin;
				regex_search(linija,xyz,xyzr);
				string doZareza12=xyz[0];
				ostatakLin=xyz.suffix().str();
			    smatch sm1;
				regex registarXYZ("r[0-7]");
				int adresiranje=-1;
				string  promenljiva; //mora dabude promenljiva
				string pomeraj; //moze i broj i promenljiva
				string cistBroj; //mora da budebroj;
				if (regex_search(doZareza12,sm1,registarXYZ)) { //stajala linija umesto doZareza ******************************************************************************************************
					//znaci regdir je ili je regindpom
					string regRez=sm1[0];
					smatch x;
					regex_search(regRez,x,digit);
					string rez123=x[0];
					int regBroj=stoi(rez123);
					string regBiti=DecimalToBinary(regBroj);
					string doZareza;
					smatch zar;
					regex nijeZarez("[^\,]+");
					regex_search(linija,zar,nijeZarez);
					doZareza=zar[0];
					string ostatakLinije1=zar.suffix().str();
					linija=zar.suffix().str();

			//		linija=sm1.suffix().str();
				//	linija=ostatakLin; //ovo mu napravi neko sranje sa adresama???????/??????????????????????????????????????????????????????????????????????????????????????????????????????????????????
					
					smatch sm2;
					regex spec("\\[.+\\]");
					if (regex_search(doZareza,sm2,spec)) {
						//znaci regindpom je
						string rez=sm2[0];
						if (DaLiJeOperandDvaRegDir == false ) cout << "ne smeju dva operanda sapomerajem";


						prvaDvaBajta=opcod + "11" + regBiti + "01" + reg2;
						GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				        string hexa=BinaryToHexa(prvaDvaBajta);
				        gk->niz.push_back(hexa);
						adresiranje=3;
				        smatch pom;
						regex_search(rez,pom,alfanum);
						pomeraj=pom[0]; 

						Simbol * simb=tabelaSimbola->get(pomeraj);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							int brojalo=stoi(pomeraj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}
						
					} else {
						//znaci regdir je
						linija=ostatakLin;
						//////////-----------------------------------------------------------------------------------------------
				        //----------------------------------------------------------------------------------------------------------------------------
						
						if (DaLiJeOperandDvaRegDir) {

						prvaDvaBajta=opcod + "01" + regBiti + "01" +reg2;
						GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				        string hexa=BinaryToHexa(prvaDvaBajta);
			          	gk->niz.push_back(hexa);

						adresiranje=1;
						locationCnt+=2;
				        linija=helper->getLine(ulaz);
				        continue;
						}

					    // sta mi je tacno ostalo u liniji ovde????????? trebalo bi da je ,drugi operand samo!!*******************************************

						if (flagRegIndZagrada ) {
							//znaci regInd sa zagradiom je
					    prvaDvaBajta=opcod + "01" + regBiti + "11" +reg2;
						GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				        string hexa=BinaryToHexa(prvaDvaBajta);
			          	gk->niz.push_back(hexa);
						regex nijeZagrada("\\[[a-z|A-Z|0-9]+\\]");
						smatch tmpalone;
						regex_search(linija,tmpalone,nijeZagrada);
						string rez1234=tmpalone[0];


						smatch blabla;
						string bla;
						regex_search(rez1234,blabla,alfanum);
						rez1234=blabla[0];
						smatch pom;
						regex_search(rez1234,pom,alfanum);
						pomeraj=pom[0]; 

						Simbol * simb=tabelaSimbola->get(pomeraj);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							int brojalo=stoi(pomeraj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}

						locationCnt +=4;
						linija=helper->getLine(ulaz);
						continue;

						}

						//proveri da li je dolar!!!!
						//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

						regex dolar("\\$");
				smatch sm;
				if (regex_search(linija,sm,dolar)) {
					//znaci regindpom sa pc rel je
				    linija=sm.suffix().str();
				//	string registar="111";
					//reg1="";
		            
					prvaDvaBajta=opcod+ "01" + regBiti + "11111";

					GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				    string hexa=BinaryToHexa(prvaDvaBajta);
			     	gk->niz.push_back(hexa);

				    adresiranje=31; //kao 3 je za regindpom, a ovo jedinaca kaze da je dolar
					smatch pom;
					regex_search(linija,pom,alfanum);
					pomeraj=pom[0];

					Simbol * simb=tabelaSimbola->get(pomeraj);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							int brojalo=stoi(pomeraj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}

                    locationCnt+=4;
					linija=helper->getLine(ulaz);
					continue;
				}

						//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
						
						
						//proveri da li je immed
				    ///immmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

				
					regex andR("\\&");
					
					if (regex_search(linija,andR)) {
						//immed je ali sa ovom &&
						smatch tmp;
						regex_search(linija,tmp,alfanum);
						promenljiva=tmp[0];
						adresiranje=4; // znaci ****************************************** 4 je za immed sa adresom
						prvaDvaBajta=opcod + "01" + regBiti + "00000";
						GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				        string hexa=BinaryToHexa(prvaDvaBajta);
			     	    gk->niz.push_back(hexa);

						Simbol * simb=tabelaSimbola->get(promenljiva);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							cout << "greska oko linije 792, sa & mora da ide neki simbol,ne moze promenljiva";
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}
						locationCnt+=4;
						linija=helper->getLine(ulaz);
						continue;
					}

					regex cifra("\ *\,?\ *[0-9]+\ *");
						if (regex_match(linija,cifra)) {
							//immed obicno je
							regex broj("[0-9]+");
							smatch tmpalo;
							regex_search(linija,tmpalo,broj);
							cistBroj=tmpalo[0];
							prvaDvaBajta=opcod + "01" + regBiti + "00000";
						    GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				            string hexa=BinaryToHexa(prvaDvaBajta);
			     	        gk->niz.push_back(hexa);
							adresiranje=0;

							int brojalo=stoi(cistBroj);
							helper->ugradi(brojalo,2,trenutnaSekcija);

							locationCnt+=4;
							linija=helper->getLine(ulaz);
							continue;
							
						}


				//immmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm


						//proveri da li je memdir
						//memdirrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
                            smatch smat;
							regex zvezdica("\\*");

							if (regex_search(linija,smat,zvezdica)) {
								//znaci memidr sa zvezdicom je
								linija=smat.suffix().str();
								regex broj("[0-9]+");
								regex_search(linija,smat,broj);
								cistBroj=smat[0];

								prvaDvaBajta=opcod + "01" + regBiti + "10000";
						        GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				                string hexa=BinaryToHexa(prvaDvaBajta);
			     	            gk->niz.push_back(hexa);
								adresiranje=21;

								int brojalo=stoi(cistBroj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
							
							locationCnt+=4;
							linija=helper->getLine(ulaz);
							continue;
							} 



							  prvaDvaBajta=opcod + "01" + regBiti + "10000";
						        GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				                string hexa=BinaryToHexa(prvaDvaBajta);
								 gk->niz.push_back(hexa);

								smatch tmp;
								regex_search(linija,tmp,alfanum);
								promenljiva=tmp[0];
								adresiranje=2;

								Simbol * simb=tabelaSimbola->get(promenljiva);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							cout << "greska oko linije 870, sa & mora da ide neki simbol,ne moze promenljiva";
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}

						locationCnt+=4;
						linija=helper->getLine(ulaz);
						continue;

						//-------------------------------------------------------------------------------------------------------
						////--------------------------------------------------------------------------------------------------------------
					}
				}
				else {
				regex dolar("\\$");
				smatch sm;
				linija=doZareza12;
				if (regex_search(linija,sm,dolar)) {
					//znaci regindpom sa pc rel je
				    linija=sm.suffix().str();
					string registar="111";
					if (DaLiJeOperandDvaRegDir== false ) cout <<"ne smejau dva operanda sa pomerajem";

					prvaDvaBajta=opcod+ "11" + registar + "01" + reg2;
					GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				    string hexa=BinaryToHexa(prvaDvaBajta);
			     	gk->niz.push_back(hexa);

				    adresiranje=31; //kao 3 je za regindpom, a ovo jedinaca kaze da je dolar
					smatch pom;
					regex_search(linija,pom,alfanum);
					pomeraj=pom[0];

					Simbol * simb=tabelaSimbola->get(pomeraj);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							int brojalo=stoi(pomeraj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}
						
						locationCnt+=4;
						linija=helper->getLine(ulaz);
						continue;

				} else {

					regex andR("\\&");
					
					if (regex_search(linija,andR)) {
						//immed je ali sa ovom &&
						smatch tmp;
						regex_search(linija,tmp,alfanum);
						promenljiva=tmp[0];
						adresiranje=4; // znaci ****************************************** 4 je za immed sa adresom
					   if (DaLiJeOperandDvaRegDir== false ) cout <<"ne smejau dva operanda sa pomerajem";

						prvaDvaBajta=opcod + "00" + "00001" + reg2;
						GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				        string hexa=BinaryToHexa(prvaDvaBajta);
			     	    gk->niz.push_back(hexa);

						Simbol * simb=tabelaSimbola->get(pomeraj);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							cout << "greska oko linije 433, sa & mora da ide neki simbol,ne moze promenljiva";
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}

						locationCnt+=4;
						linija=helper->getLine(ulaz);
						continue;

					} else {
						regex cifra("\ *[0-9]+\ *");
						if (regex_match(linija,cifra)) {
							//immed obicno je
							regex broj("[0-9]+");
							smatch tmpalo;
							regex_search(linija,tmpalo,broj);
							cistBroj=tmpalo[0];
							if (DaLiJeOperandDvaRegDir== false ) cout <<"ne smejau dva operanda sa pomerajem";

							prvaDvaBajta=opcod + "00" + "00001" + reg2;
						    GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				            string hexa=BinaryToHexa(prvaDvaBajta);
			     	        gk->niz.push_back(hexa);
							adresiranje=0;

							int brojalo=stoi(cistBroj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
							locationCnt+=4;
						linija=helper->getLine(ulaz);
						continue;
							
						} else {
							//znaci mora biti memdir
							smatch smat;
							regex zvezdica("\\*");
							if (regex_search(linija,smat,zvezdica)) {
								//znaci memidr sa zvezdicom je
								linija=smat.suffix().str();
								regex broj("[0-9]+");
								regex_search(linija,smat,broj);
								cistBroj=smat[0];
								if (DaLiJeOperandDvaRegDir== false ) cout <<"ne smejau dva operanda sa pomerajem";
								prvaDvaBajta=opcod + "10" + "00001" + reg2;
						        GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				                string hexa=BinaryToHexa(prvaDvaBajta);
			     	            gk->niz.push_back(hexa);
								adresiranje=21;

								int brojalo=stoi(cistBroj);
							helper->ugradi(brojalo,2,trenutnaSekcija);
							locationCnt+=4;
						linija=helper->getLine(ulaz);
						continue;
							

							} else {
								//znaci obican memdir je 
								if (DaLiJeOperandDvaRegDir== false ) cout <<"ne smejau dva operanda sa pomerajem";

						        prvaDvaBajta=opcod + "10" + "00001" + reg2;
						        GenerisanKod * gk=mapaGenKoda[trenutnaSekcija];
				                string hexa=BinaryToHexa(prvaDvaBajta);
								 gk->niz.push_back(hexa);

								smatch tmp;
								regex_search(linija,tmp,alfanum);
								promenljiva=tmp[0];
								adresiranje=2;

								Simbol * simb=tabelaSimbola->get(promenljiva);
						if (simb == 0) {
							//znaci ovo mora biti cist brojondab
							cout << "greska oko linije 433, sa & mora da ide neki simbol,ne moze promenljiva";
						} else {
							//dodaj ovo u tabelu realokacija******************************************************
							helper->dodajRelSimbol(locationCnt + 2,trenutnaSekcija,simb,false);
							helper->ugradi(simb->getVrednost(),2,trenutnaSekcija);
						}
						locationCnt+=4;
						linija=helper->getLine(ulaz);
						continue;
							}


						}
					}

				}

				}



			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		} // kraj instrukcija

		//znaci ostale su jos sve direktive!!!!!!!!!!!!

		if (sledecaRec == ".text" || sledecaRec ==".data" ||sledecaRec == ".rodata" || sledecaRec ==".bss") {
			
		//	locationCnt=0;
			pocetakTrenSekcije=locationCnt;
			trenutnaSekcija=sledecaRec;
			linija=helper->getLine(ulaz);
			continue;
		}

		if (sledecaRec == ".global") {
			linija=helper->getLine(ulaz);
			continue;
		}

		if (sledecaRec ==  ".char" || sledecaRec == ".word" || sledecaRec == ".long" ) {

			int dodatak=helper->uzmiVelicinuBajtaDirektive(sledecaRec);
			regex nijeZarez("[^\,]+");
			string tmp;
			smatch rez;

			while (regex_search(linija,rez,nijeZarez)) {
				string tmp=rez[0];
				smatch smx;
				if(regex_search(tmp,smx,alfanum)){
					string imeNekogSimbola=smx[0];
					Simbol * simbolNeki=tabelaSimbola->get(imeNekogSimbola);
					int broj;
					if (simbolNeki ==  0)
					 broj=stoi(smx[0]);
					else {
						broj=simbolNeki->getVrednost();
						helper->dodajRelSimbol(locationCnt,trenutnaSekcija, simbolNeki,false);
					}
					helper->ugradi(broj,dodatak,trenutnaSekcija);
				}else{
					cout <<"greska okolinije 966 nema nista uz long/char/word direktivu?";
				}

				locationCnt+=dodatak;

				linija=rez.suffix().str();
			}

			linija=helper->getLine(ulaz);
			continue;
		}

		if (sledecaRec == ".skip") {
			 
			regex broj("[0-9]+");
			smatch sm;
			regex_search(linija,sm, broj);

			string brojS=sm[0];
			
			locationCnt+=stoi(brojS);

			linija=helper->getLine(ulaz);
			continue;
		}

			if ( sledecaRec == ".align" ) {
			
			smatch sm;
			regex digit("[0-9]+");
			if (regex_search(linija,sm,digit) ){

				int delilac=stoi(sm[0]);
				delilac=pow(2,delilac);
				int ostatak=locationCnt % delilac;
				if (ostatak == 0) {
					linija=helper->getLine(ulaz);
					continue;
				}
				locationCnt=locationCnt +  (delilac - ostatak);
				linija=helper->getLine(ulaz);
				continue;

			}else 
			{
				cout << "greska nemanista uz align, okolinije  247" << endl;
			}


		}

	




	}



	return 0;

}

string Asembler::DecimalToHexa(int dec) {
		string rez = "";
	if (dec == 0) {
		rez = "0"; return rez;
	}
	else if (dec < 0) { unsigned int neo = dec; bitset<16> consta(neo); return GetHexFromBin(consta.to_string()); }
	int rem;
	while (dec > 0) {
		rem = dec % 16;
		if (rem > 9) {
			switch (rem) {
			case 10: rez="A"+rez; break;
			case 11: rez="B"+rez; break;
			case 12: rez="C"+rez; break;
			case 13: rez="D"+rez; break;
			case 14: rez="E"+rez; break;
			case 15: rez="F"+rez; break;
			}
		}
		else {
			rez = char(rem + 48) + rez;
		}
		dec = dec / 16;
	}
	

	return rez;

}


string Asembler::GetHexFromBin(string sBinary) {
	string rest(""), tmp, chr = "0000";
	int len = sBinary.length() / 4;
	chr = chr.substr(0, len);
	//sBinary = chr + sBinary;
	for (unsigned int i = 0; i < sBinary.length(); i += 4)
	{
		tmp = sBinary.substr(i, 4);
		if (!tmp.compare("0000"))
		{
			rest = rest + "0";
		}
		else if (!tmp.compare("0001"))
		{
			rest = rest + "1";
		}
		else if (!tmp.compare("0010"))
		{
			rest = rest + "2";
		}
		else if (!tmp.compare("0011"))
		{
			rest = rest + "3";
		}
		else if (!tmp.compare("0100"))
		{
			rest = rest + "4";
		}
		else if (!tmp.compare("0101"))
		{
			rest = rest + "5";
		}
		else if (!tmp.compare("0110"))
		{
			rest = rest + "6";
		}
		else if (!tmp.compare("0111"))
		{
			rest = rest + "7";
		}
		else if (!tmp.compare("1000"))
		{
			rest = rest + "8";
		}
		else if (!tmp.compare("1001"))
		{
			rest = rest + "9";
		}
		else if (!tmp.compare("1010"))
		{
			rest = rest + "A";
		}
		else if (!tmp.compare("1011"))
		{
			rest = rest + "B";
		}
		else if (!tmp.compare("1100"))
		{
			rest = rest + "C";
		}
		else if (!tmp.compare("1101"))
		{
			rest = rest + "D";
		}
		else if (!tmp.compare("1110"))
		{
			rest = rest + "E";
		}
		else if (!tmp.compare("1111"))
		{
			rest = rest + "F";
		}
		else
		{
			continue;
		}
	}
	return rest;
}

string Asembler::BinaryToHexa(string sBinary) {
	string rest(""), tmp, chr = "0000";
	int len = sBinary.length() / 4;
	chr = chr.substr(0, len);
	//sBinary = chr + sBinary;
	for (unsigned int i = 0; i < sBinary.length(); i += 4)
	{
		tmp = sBinary.substr(i, 4);
		if (!tmp.compare("0000"))
		{
			rest = rest + "0";
		}
		else if (!tmp.compare("0001"))
		{
			rest = rest + "1";
		}
		else if (!tmp.compare("0010"))
		{
			rest = rest + "2";
		}
		else if (!tmp.compare("0011"))
		{
			rest = rest + "3";
		}
		else if (!tmp.compare("0100"))
		{
			rest = rest + "4";
		}
		else if (!tmp.compare("0101"))
		{
			rest = rest + "5";
		}
		else if (!tmp.compare("0110"))
		{
			rest = rest + "6";
		}
		else if (!tmp.compare("0111"))
		{
			rest = rest + "7";
		}
		else if (!tmp.compare("1000"))
		{
			rest = rest + "8";
		}
		else if (!tmp.compare("1001"))
		{
			rest = rest + "9";
		}
		else if (!tmp.compare("1010"))
		{
			rest = rest + "A";
		}
		else if (!tmp.compare("1011"))
		{
			rest = rest + "B";
		}
		else if (!tmp.compare("1100"))
		{
			rest = rest + "C";
		}
		else if (!tmp.compare("1101"))
		{
			rest = rest + "D";
		}
		else if (!tmp.compare("1110"))
		{
			rest = rest + "E";
		}
		else if (!tmp.compare("1111"))
		{
			rest = rest + "F";
		}
		else
		{
			continue;
		}
	}
	return rest;
}

string Asembler::DecimalToBinary(int n) {
	std::string r;
    while(n!=0) {r=(n%2==0 ?"0":"1")+r; n/=2;}

	while (r.length() < 3) {
	r="0" + r;
	}
    return r;
}

