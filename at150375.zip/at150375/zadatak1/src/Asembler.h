#ifndef ASEMBLER_H
#define ASEMBLER_H

#include "TabelaSimbola.h"
#include <fstream>
#include "Helper.h"
#include <vector>
#include "RelSimbol.h"
#include <map>




class Sekcija {
public:
	string ime;
	int  duzina;
	int pocetak;
	int kraj;

	Sekcija(string i, int pocetak, int kraj) : ime(i), pocetak(pocetak), kraj(kraj) { duzina=kraj-pocetak; }

};


class Asembler {
public:

	Asembler(int rb,int pocAdresa);
	~Asembler();

	int prviProlaz(ifstream & of);
	int drugiProlaz(ifstream & of);


private:
   
   static string DecimalToHexa(int dec);
   static string BinaryToHexa(string sBinary);
   static string DecimalToBinary(int n);
   static string GetHexFromBin(string sBinary);

	friend class Helper;

public:
	long int pocAdresa;

	Helper * helper;
	static TabelaSimbola * tabelaSimbola;
	long int locationCnt;
	long int pocetakTrenSekcije;
    long int rb;
	string trenutnaSekcija;
    static	vector <Sekcija> duzineSekcija; //sekcija ima pocetak i kraj..

static	map <string,RelZapisi *> mapaRel;

static	map <string,GenerisanKod *> mapaGenKoda;

	


};
#endif