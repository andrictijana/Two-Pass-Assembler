#ifndef HELPER_H
#define HELPER_H
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include "Ins.h"
#include <fstream>
#include "TabelaSimbola.h"

using namespace std;



class Helper {

public:

	Helper();

	string getLine(ifstream & a );
	int redniBrojSekcije(string sek);
	int uzmiVelicinuBajtaDirektive(string dir);

	void ispisiTabeluSimbola(ofstream & );
	void ispisiDrugiDeo(ofstream & );

	void dodajRelSimbol(int locCnt,string trenutnaSekcija,Simbol * simbol,bool tip);

	void ugradi(int,int,string);


	
public:

	map<string,Ins * > instrukcije;



};
#endif
