#ifndef RELSIMBOL_H
#define RELSIMBOL_H

#include <iostream>

#include <vector>

using namespace std;

//flagTip == true -> relativno adresiranje
//flagTip == false -> apsolutno adresiranje

class RelSimbol {
public:
	string adresa;
	bool flagTip;
	int zavisiOdRB;

	
};


class RelZapisi{
public:
	vector  <RelSimbol * > niz;

};

class GenerisanKod {
public:
	vector <string> niz;
};
#endif