

#include "Asembler.h"
#include <assert.h>


int main(int argc, char * argv []) {

	ifstream ulaz;
	ofstream izlaz;
        int adresa=atoi(argv[2]);
	ulaz.open(argv[1]);
	
	
	Asembler a(5,adresa);

	a.prviProlaz(ulaz);
	cout << endl<<"gotov prviprolaz " <<endl;
	izlaz.open("izlaz.txt");
	a.helper->ispisiTabeluSimbola(izlaz);
	cout << endl <<"gotov ispis" << endl;

	ulaz.close();

	ulaz.open(argv[1]);
	a.drugiProlaz(ulaz);
	cout << endl<<"gotov drugiprolaz";
	a.helper->ispisiDrugiDeo(izlaz);
	cout << endl<< "gotovo"<< endl;

	int nnn; 
	cin >>nnn;



	return 0;



}
