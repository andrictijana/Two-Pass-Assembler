

#include "Asembler.h"

#include <string>
#include <regex>

using namespace std;


string Helper::getLine(ifstream & ulaz ) {

	string linija;

	std::getline(ulaz,linija);

	return linija;


}


Helper::Helper() {

	//sve ins u mapu
	Ins * nova=new Ins();
	nova->ime="aladd";
	nova->opcode="110000";
    instrukcije["aladd"]=nova;

	 nova=new Ins();
	nova->ime="alsub";
	nova->opcode="110001";
    instrukcije["alsub"]=nova;

	 nova=new Ins();
	nova->ime="almul";
	nova->opcode="110010";
    instrukcije["almul"]=nova;

	 nova=new Ins();
	nova->ime="aldiv";
	nova->opcode="110011";
    instrukcije["aldiv"]=nova;

	 nova=new Ins();
	nova->ime="alcmp";
	nova->opcode="110100";
    instrukcije["alcmp"]=nova;

	 nova=new Ins();
	nova->ime="aland";
	nova->opcode="110101";
    instrukcije["aland"]=nova;

	 nova=new Ins();
	nova->ime="alor";
	nova->opcode="110110";
    instrukcije["alor"]=nova;

 nova=new Ins();
	nova->ime="alnot";
	nova->opcode="110111";
    instrukcije["alnot"]=nova;

	 nova=new Ins();
	nova->ime="altest";
	nova->opcode="111000";
    instrukcije["altest"]=nova;

 nova=new Ins();
	nova->ime="alpush";
	nova->opcode="111001";
    instrukcije["alpush"]=nova;

	 nova=new Ins();
	nova->ime="alpop";
	nova->opcode="111010";
    instrukcije["alpop"]=nova;

	 nova=new Ins();
	nova->ime="alcall";
	nova->opcode="111011";
    instrukcije["alcall"]=nova;

	 nova=new Ins();
	nova->ime="aliret";
	nova->opcode="111100";
    instrukcije["aliret"]=nova;

	 nova=new Ins();
	nova->ime="almov";
	nova->opcode="111101";
    instrukcije["almov"]=nova;

	 nova=new Ins();
	nova->ime="alshl";
	nova->opcode="111110";
    instrukcije["alshl"]=nova;

	 nova=new Ins();
	nova->ime="alshr";
	nova->opcode="111111";
    instrukcije["alshr"]=nova;

 nova=new Ins();
	nova->ime="alret";
	nova->opcode="111010";
    instrukcije["alret"]=nova;

 nova=new Ins();
	nova->ime="aljmp";
	nova->opcode="111101";
    instrukcije["aljmp"]=nova;


	/////////////////////////eq

	 nova=new Ins();
	nova->ime="eqadd";
	nova->opcode="000000";
    instrukcije["eqadd"]=nova;

 nova=new Ins();
	nova->ime="eqsub";
	nova->opcode="000001";
    instrukcije["eqsub"]=nova;

	 nova=new Ins();
	nova->ime="eqmul";
	nova->opcode="000010";
    instrukcije["eqmul"]=nova;

	 nova=new Ins();
	nova->ime="eqdiv";
	nova->opcode="000011";
    instrukcije["eqdiv"]=nova;

	 nova=new Ins();
	nova->ime="eqcmp";
	nova->opcode="000100";
    instrukcije["eqcmp"]=nova;

	 nova=new Ins();
	nova->ime="eqand";
	nova->opcode="000101";
    instrukcije["eqand"]=nova;

	 nova=new Ins();
	nova->ime="eqor";
	nova->opcode="000110";
    instrukcije["eqor"]=nova;

	 nova=new Ins();
	nova->ime="eqnot";
	nova->opcode="000111";
    instrukcije["eqnot"]=nova;

	 nova=new Ins();
	nova->ime="eqtest";
	nova->opcode="001000";
    instrukcije["eqtest"]=nova;

	 nova=new Ins();
	nova->ime="eqpush";
	nova->opcode="001001";
    instrukcije["eqpush"]=nova;

	 nova=new Ins();
	nova->ime="eqpop";
	nova->opcode="001010";
    instrukcije["eqpop"]=nova;

 nova=new Ins();
	nova->ime="eqcall";
	nova->opcode="001011";
    instrukcije["eqcall"]=nova;

	nova=new Ins();
	nova->ime="eqiret";
	nova->opcode="001100";
    instrukcije["eqiret"]=nova;

	 nova=new Ins();
	nova->ime="eqmov";
	nova->opcode="001101";
    instrukcije["eqmov"]=nova;

	 nova=new Ins();
	nova->ime="eqshl";
	nova->opcode="001110";
    instrukcije["eqshl"]=nova;

	 nova=new Ins();
	nova->ime="eqshr";
	nova->opcode="001111";
    instrukcije["eqshr"]=nova;

 nova=new Ins();
	nova->ime="eqret";
	nova->opcode="001010";
    instrukcije["eqret"]=nova;

 nova=new Ins();
	nova->ime="eqjmp";
	nova->opcode="001101";
    instrukcije["eqjmp"]=nova;

	//////////////////////////////////////////////////qe

	//////////////////////////////////ne

 nova=new Ins();
	nova->ime="neadd";
	nova->opcode="010000";
    instrukcije["neadd"]=nova;

	 nova=new Ins();
	nova->ime="nesub";
	nova->opcode="010001";
    instrukcije["nesub"]=nova;

	 nova=new Ins();
	nova->ime="nemul";
	nova->opcode="010010";
    instrukcije["nemul"]=nova;

	 nova=new Ins();
	nova->ime="nediv";
	nova->opcode="010011";
    instrukcije["nediv"]=nova;

	 nova=new Ins();
	nova->ime="necmp";
	nova->opcode="010100";
    instrukcije["necmp"]=nova;

	 nova=new Ins();
	nova->ime="neand";
	nova->opcode="010101";
    instrukcije["neand"]=nova;

	 nova=new Ins();
	nova->ime="neor";
	nova->opcode="010110";
    instrukcije["neor"]=nova;

	 nova=new Ins();
	nova->ime="nenot";
	nova->opcode="010111";
    instrukcije["nenot"]=nova;

	 nova=new Ins();
	nova->ime="netest";
	nova->opcode="011000";
    instrukcije["netest"]=nova;

 nova=new Ins();
	nova->ime="nepush";
	nova->opcode="011001";
    instrukcije["nepush"]=nova;

	 nova=new Ins();
	nova->ime="nepop";
	nova->opcode="011010";
    instrukcije["nepop"]=nova;

	 nova=new Ins();
	nova->ime="necall";
	nova->opcode="011011";
    instrukcije["necall"]=nova;

	 nova=new Ins();
	nova->ime="neiret";
	nova->opcode="011100";
    instrukcije["neiret"]=nova;

	 nova=new Ins();
	nova->ime="nemov";
	nova->opcode="011101";
    instrukcije["nemov"]=nova;

	 nova=new Ins();
	nova->ime="neshl";
	nova->opcode="011110";
    instrukcije["neshl"]=nova;

	 nova=new Ins();
	nova->ime="neshr";
	nova->opcode="011111";
    instrukcije["neshr"]=nova;

	 nova=new Ins();
	nova->ime="neret";
	nova->opcode="011010";
    instrukcije["neret"]=nova;

	 nova=new Ins();
	nova->ime="nejmp";
	nova->opcode="011101";
    instrukcije["nejmp"]=nova;


	/////////////////////////////////en

	///////////////////////////gt

	 nova=new Ins();
	nova->ime="gtadd";
	nova->opcode="100000";
    instrukcije["gtadd"]=nova;

	 nova=new Ins();
	nova->ime="gtsub";
	nova->opcode="100001";
    instrukcije["gtsub"]=nova;

	 nova=new Ins();
	nova->ime="gtmul";
	nova->opcode="100010";
    instrukcije["gtmul"]=nova;

	nova=new Ins();
	nova->ime="gtdiv";
	nova->opcode="100011";
    instrukcije["gtdiv"]=nova;

	 nova=new Ins();
	nova->ime="gtcmp";
	nova->opcode="100100";
    instrukcije["gtcmp"]=nova;

nova=new Ins();
	nova->ime="gtand";
	nova->opcode="100101";
    instrukcije["gtand"]=nova;

	 nova=new Ins();
	nova->ime="gtor";
	nova->opcode="100110";
    instrukcije["gtor"]=nova;
 nova=new Ins();
	nova->ime="gtnot";
	nova->opcode="100111";
    instrukcije["gtnot"]=nova;

	 nova=new Ins();
	nova->ime="gttest";
	nova->opcode="101000";
    instrukcije["gttest"]=nova;

	 nova=new Ins();
	nova->ime="gtpush";
	nova->opcode="101001";
    instrukcije["gtpush"]=nova;

	 nova=new Ins();
	nova->ime="gtpop";
	nova->opcode="101010";
    instrukcije["gtpop"]=nova;

	nova=new Ins();
	nova->ime="gtcall";
	nova->opcode="101011";
    instrukcije["gtcall"]=nova;

	 nova=new Ins();
	nova->ime="gtiret";
	nova->opcode="101100";
    instrukcije["gtiret"]=nova;

	 nova=new Ins();
	nova->ime="gtmov";
	nova->opcode="101101";
    instrukcije["gtmov"]=nova;

	 nova=new Ins();
	nova->ime="gtshl";
	nova->opcode="101110";
    instrukcije["gtshl"]=nova;

	 nova=new Ins();
	nova->ime="gtshr";
	nova->opcode="101111";
    instrukcije["gtshr"]=nova;

 nova=new Ins();
	nova->ime="gtret";
	nova->opcode="101010";
    instrukcije["gtret"]=nova;

	 nova=new Ins();
	nova->ime="gtjmp";
	nova->opcode="101101";
    instrukcije["gtjmp"]=nova;

	////////////////////////////tg



}


int Helper::redniBrojSekcije(string sek) {
	if(sek ==".text") return 1;
	if(sek == ".data")return 2;
	if(sek == ".rodata")return 3;
	if(sek== ".bss") return 4;
	cout <<"greska  nepostojeca sekcija";

}

int Helper::uzmiVelicinuBajtaDirektive(string dir) {

	if (dir == ".char") return 1;
	if (dir== ".word") return 2;
	if(dir == ".long") return 4;

}


void Helper::ispisiTabeluSimbola(ofstream & izlaz){

	izlaz << "\t"  << "Sekcije: " << endl;
	izlaz << "ime  " << "\t\t" << "pocetak" << "\t\t" << "kraj"  << "\t\t" << "duzina" << endl;
	vector<Sekcija>::iterator iter;
	for (iter=Asembler::duzineSekcija.begin(); iter!=Asembler::duzineSekcija.end(); iter++) {
		izlaz << iter->ime << "\t\t" << iter->pocetak << "\t\t" << iter->kraj<< "\t\t" << iter->duzina << endl;
	}
	izlaz << endl << endl;

	izlaz << "\t" << " Tabela simbola" << endl;
	izlaz << "ime" << "\t\t" << "sekcija" <<"\t\t" << "vred" << "\t\t" << "loc/glo" <<"\t\t" << "rb"<< endl;

  for(  map<string,Simbol * >::iterator i= Asembler::tabelaSimbola->mapa.begin(); i!=Asembler::tabelaSimbola->mapa.end(); i++) {
	  Simbol * s=i->second;

	 izlaz  <<  s->getIme() << "\t\t" << s->getSekcija()<< "\t\t" << s->getVrednost() << "  \t\t" << s->getLG() << "\t\t"  << s->getRb() << endl;


  }


}

void Helper::ugradi(int broj,int brojBajtova,string sekcija) {
	if (sekcija == ".bss" ) return;
	string hexa=Asembler::DecimalToHexa(broj);
	if (brojBajtova ==4) {
		if (hexa.length() > 8){
			cout <<"len vece od 4B u ugradi";
			return ;
		}
		string niz[8]={"0","0","0","0","0","0","0","0"}; int n=0;
		regex cifra("[0-9|a-f|A-F]");
		smatch sm;
		while (regex_search(hexa,sm,cifra)) {
			string tmp=sm[0];
			niz[n]=tmp;
			n+=1;

			hexa=sm.suffix().str();

		}

		string bajts[4]={"00","00","00","00"};
		int m=0;
		int i=n-1;
		for (; i>0; i-=2 ) {
			string tempalo=niz[i-1] + niz[i];
			bajts[m]=tempalo;
			m+=1;
		}
		if (i== 0) {
			bajts[m++]="0" + niz[0];
		}
		for (int i=0; i<4; i+=2) {
		Asembler::mapaGenKoda[sekcija]->niz.push_back(bajts[i] + bajts[i+1]);
		}
		
		return;
		
	}

	if (brojBajtova ==2 ) {
		if (hexa.length() > 4){
			cout <<"len vece od 2B u ugradi";
			return ;
		}
		string niz[4]={"0","0","0","0"}; int n=0;
		regex cifra("[0-9|a-f|A-F]");
		smatch sm;
		while (regex_search(hexa,sm,cifra)) {
			string tmp=sm[0];
			niz[n]=tmp;
			n+=1;

			hexa=sm.suffix().str();

		}

		string bajts[2]={"00","00"};
		int m=0;
		int i=n-1;
		for (; i>0; i-=2 ) {
			string tempalo=niz[i-1] + niz[i];
			bajts[m]=tempalo;
			m+=1;
		}
		if (i== 0) {
			bajts[m++]="0" + niz[0];
		}
		for (int i=0; i<2; i+=2) {
		Asembler::mapaGenKoda[sekcija]->niz.push_back(bajts[i] + bajts[i+1]);
		}
		
		return;
	}

	if (brojBajtova == 1) {
		if (hexa.length() > 2){
			cout <<"len vece od 1B u ugradi";
			return ;
		}
		string niz[2]={"0","0"}; int n=0;
		regex cifra("[0-9|a-f|A-F]");
		smatch sm;
		while (regex_search(hexa,sm,cifra)) {
			string tmp=sm[0];
			niz[n]=tmp;
			n+=1;

			hexa=sm.suffix().str();

		}

		string bajts[1]={"00"};
		int m=0;
		int i=n-1;
		for (; i>0; i-=2 ) {
			string tempalo=niz[i-1] + niz[i];
			bajts[m]=tempalo;
			m+=1;
		}
		if (i==0) bajts[m++]="0" + niz[0];
		Asembler::mapaGenKoda[sekcija]->niz.push_back(bajts[0]);
		
		return;
	}
	cout <<"eror u funkciji ugradi" << endl;
}

void Helper::dodajRelSimbol(int locCnt,string trenutnaSekcija,Simbol * simbol,bool tip) {
	if (simbol == 0) {
		cout<< "helper 81,simbol je0";
		return;
	}

	if (simbol->getSekcija() == trenutnaSekcija && tip ) return;


	if (simbol->getLG() == "local" ) {
		int rb;
	    rb=Asembler::tabelaSimbola->get(trenutnaSekcija)->getRb();

		RelSimbol *novi=new RelSimbol();
		novi->zavisiOdRB=rb;
		novi->adresa=Asembler::DecimalToHexa(locCnt);
		novi->flagTip=tip;

		Asembler::mapaRel[trenutnaSekcija]->niz.push_back(novi);
		
		return;
	}

	int rb=simbol->getRb();
	RelSimbol *novi=new RelSimbol();
		novi->zavisiOdRB=rb;
		novi->adresa=Asembler::DecimalToHexa(locCnt);
		novi->flagTip=tip;

		Asembler::mapaRel[trenutnaSekcija]->niz.push_back(novi);
		return;

}


void Helper::ispisiDrugiDeo(ofstream & izlaz ) {

	izlaz << endl << "\t\t" << "RelZapisi za Text sekciju " << endl << "adresa" <<  "\t\t" << "tip   " << "\t\t" << "rb"<<endl;
	 
	for (vector<RelSimbol *>::iterator i=(Asembler::mapaRel[".text"])->niz.begin(); 
		i!=(Asembler::mapaRel[".text"])->niz.end(); i++ ) {
			RelSimbol *cur=(*i);
			string ispis="R_386_32";
			if (cur->flagTip) ispis+="_PC32";
			izlaz << cur->adresa << "\t\t" << ispis << "\t\t" << cur->zavisiOdRB << endl;

	       
	}

	izlaz << endl << "\t\t" << "RelZapisi za Data sekciju " << endl << "adresa" <<  "\t\t" << "tip   " << "\t\t" << "rb"<<endl;
	 
	for (vector<RelSimbol *>::iterator i=(Asembler::mapaRel[".data"])->niz.begin(); 
		i!=(Asembler::mapaRel[".data"])->niz.end(); i++ ) {
			RelSimbol *cur=(*i);
			string ispis="R_386_32";
			if (cur->flagTip) ispis+="_PC32";
			izlaz << cur->adresa << "\t\t" << ispis << "\t\t" << cur->zavisiOdRB << endl;

	       
	}


	izlaz << endl << "\t\t" << "RelZapisi za Rodata sekciju " << endl << "adresa" <<  "\t\t" << "tip   " << "\t\t" << "rb"<<endl;
	 
	for (vector<RelSimbol *>::iterator i=(Asembler::mapaRel[".rodata"])->niz.begin(); 
		i!=(Asembler::mapaRel[".rodata"])->niz.end(); i++ ) {
			RelSimbol *cur=(*i);
			string ispis="R_386_32";
			if (cur->flagTip) ispis+="_PC32";
			izlaz << cur->adresa << "\t\t" << ispis << "\t\t" << cur->zavisiOdRB << endl;

	       
	}

	izlaz << endl<< endl << "#text code" << endl;

	for (vector<string>::iterator i=Asembler::mapaGenKoda[".text"]->niz.begin();
		i!=Asembler::mapaGenKoda[".text"]->niz.end(); i++) {
			izlaz << (*i) << "  ";
	}

	izlaz << endl<< endl << "#data code" << endl;

	for (vector<string>::iterator i=Asembler::mapaGenKoda[".data"]->niz.begin();
		i!=Asembler::mapaGenKoda[".data"]->niz.end(); i++) {
			izlaz << (*i) << "  ";
	}

	izlaz << endl<< endl << "#rodata code" << endl;

	for (vector<string>::iterator i=Asembler::mapaGenKoda[".rodata"]->niz.begin();
		i!=Asembler::mapaGenKoda[".rodata"]->niz.end(); i++) {
			izlaz << (*i) << "  ";
	}
}